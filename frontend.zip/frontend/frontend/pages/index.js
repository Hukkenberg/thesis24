export default function Home() {
  return (
    <div className="container">
      <h1>Welcome to Healthcare Management System</h1>
      <p>Use the navigation to access your features.</p>
    </div>
  );
}
