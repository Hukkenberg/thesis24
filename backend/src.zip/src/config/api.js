const API_URL = 'http://localhost:5000'; // Ensure this matches the backend URL
export default API_URL;
