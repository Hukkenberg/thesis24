const logger = (message) => console.log(`[LOG]: ${message}`);
module.exports = logger;
