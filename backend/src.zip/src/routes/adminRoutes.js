const express = require('express');
const { getAllUsers, updateUserRole } = require('../controllers/adminController');
const { authenticate } = require('../middlewares/authenticate');
const { authorize } = require('../middlewares/roleMiddleware');

const router = express.Router();

router.get('/users', authenticate, authorize(['admin']), getAllUsers);
router.put('/update-role', authenticate, authorize(['admin']), updateUserRole);

module.exports = router;
