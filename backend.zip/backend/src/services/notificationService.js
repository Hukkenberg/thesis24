
const sendNotification = (email, message) => {
  console.log(`Sending notification to ${email}: ${message}`);
};

module.exports = { sendNotification };
